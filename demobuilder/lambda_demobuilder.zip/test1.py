import json
import requests

api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"

url = 'https://app.launchdarkly.com/api/v2/members?filter=lastSeen:{"before":1666649476000}&limit=20'
# url = 'https://app.launchdarkly.com/api/v2/members?filter=lastSeen:{"noData":true}&limit=100'

headers = {
    "Authorization": api_key,
    "Content-Type": "application/json",
}

res = requests.get(url, headers=headers)
data = json.loads(res.text)
for item in data["items"]:
    memberid = item["_id"]
    if item["_pendingInvite"]:
        fullname = "Pending Invite"
    else:
        fullname = item["firstName"] + " " + item["lastName"]
    print(item["email"] + " (" + fullname + ")")

print("Total: " + str(data["totalCount"]))
