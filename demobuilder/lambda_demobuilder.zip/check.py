import os
import sys
import json
import requests
import time
from datetime import datetime
import arrow
import boto3


project_key = "cxld-massive-mortar"
api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"
env_key = "production"
# temp_api_key = ""
# email = "leonard.winata@izeno.com"

url = "https://app.launchdarkly.com/api/v2/tokens"  # + temp_api_key

headers = {
    "Authorization": temp_api_key,
    "Content-Type": "application/json",
}

res = requests.get(url, headers=headers)
data = json.loads(res.text)
for item in data["items"]:
    if item["_member"]["email"] == email:
        print("Service Token: " + str(item["serviceToken"]))
        print("Role: " + item["role"])

# print(res.text)
