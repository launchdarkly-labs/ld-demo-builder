import os
import sys
import json
import requests

project_key = "cxld-rust-kern"


def add_pipeline_flag(flag_key, pipeline_key, pipeline_stage_id):
    url = (
        "https://app.launchdarkly.com/api/v2/projects/"
        + project_key
        + "/flags/"
        + flag_key
        + "/release"
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": "api-451cd896-2388-4aaa-a713-11807acdf8c6",
        "LD-API-Version": "beta",
    }

    payload = {
        "releaseVariationId": pipeline_stage_id,
        "releasePipelineKey": pipeline_key,
    }

    response = requests.put(url, json=payload, headers=headers)
    print(response.text)


flag_key = "release-ai-asst"
# Testing phase ID:
test_stage_id = "bcf664cc-89bd-4a8c-8188-547e5f34b930"
# Guarded Releases ID:
guard_stage_id = "b138cc27-6687-4c44-b064-389f9c64eb78"
# GA ID:
ga_stage_id = "dc04daaa-b30b-47f7-bd27-bfa4f7a668e5"

# add_pipeline_flag("release-ai-asst", "default-releases", test_stage_id)
# add_pipeline_flag(
#     "release-updated-charting-algorithm", "default-releases", test_stage_id
# )
# add_pipeline_flag("release-ddos-protection", "default-releases", test_stage_id)
# add_pipeline_flag("release-force-update", "default-releases", test_stage_id)
# add_pipeline_flag("release-advisor-insights", "default-releases", test_stage_id)
# add_pipeline_flag("release-broker-dashboard", "default-releases", test_stage_id)
# add_pipeline_flag("release-debug-logging", "default-releases", test_stage_id)
# add_pipeline_flag("release-profile-ui", "default-releases", test_stage_id)
# add_pipeline_flag("release-api-rate-limit", "default-releases", test_stage_id)
# add_pipeline_flag("release-currency-exchange", "default-releases", test_stage_id)


def advance_flag_stage(flag_key, status, pipeline_stage_id):
    url = (
        "https://app.launchdarkly.com/api/v2/projects/"
        + project_key
        + "/flags/"
        + flag_key
        + "/release/phases/"
        + pipeline_stage_id
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": "api-451cd896-2388-4aaa-a713-11807acdf8c6",
        "LD-API-Version": "beta",
    }

    payload = {"status": status}

    response = requests.put(url, json=payload, headers=headers)
    print(response.text)


def attach_metric_to_flag(flag_key, metric_key=[]):
    url = (
        "https://app.launchdarkly.com/api/v2/projects/"
        + project_key
        + "/flags/"
        + flag_key
        + "/measured-rollout-configuration"
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": "api-451cd896-2388-4aaa-a713-11807acdf8c6",
        "LD-API-Version": "beta",
    }

    payload = {"metricKeys": metric_key}

    response = requests.put(url, json=payload, headers=headers)
    print(response.text)


####
## For:
## - release-ddos-protection
## - release-force-update
##
## bump from testing to guarded
####
# advance_flag_stage("release-ddos-protection", "active", test_stage_id)
# advance_flag_stage("release-ddos-protection", "completed", test_stage_id)

# advance_flag_stage("release-force-update", "active", test_stage_id)
# advance_flag_stage("release-force-update", "completed", test_stage_id)

####
## For:
## - release-advisor-insights
## - release-broker-dashboard
## - release-debug-logging
## - release-profile-ui
##
## bump from testing to GA
####
# # first add metrics to flags
# # second bump to guarded

# attach_metric_to_flag("release-advisor-insights", ["error-rate"])
# advance_flag_stage("release-advisor-insights", "active", test_stage_id)
# advance_flag_stage("release-advisor-insights", "completed", test_stage_id)
# advance_flag_stage("release-advisor-insights", "active", guard_stage_id)
# advance_flag_stage("release-advisor-insights", "completed", guard_stage_id)

# attach_metric_to_flag("release-broker-dashboard", ["error-rate", "latency"])
# advance_flag_stage("release-broker-dashboard", "active", test_stage_id)
# advance_flag_stage("release-broker-dashboard", "completed", test_stage_id)
# advance_flag_stage("release-broker-dashboard", "active", guard_stage_id)
# advance_flag_stage("release-broker-dashboard", "completed", guard_stage_id)

# attach_metric_to_flag("release-debug-logging", ["latency"])
# advance_flag_stage("release-debug-logging", "active", test_stage_id)
# advance_flag_stage("release-debug-logging", "completed", test_stage_id)
# advance_flag_stage("release-debug-logging", "active", guard_stage_id)
# advance_flag_stage("release-debug-logging", "completed", guard_stage_id)

# attach_metric_to_flag("release-profile-ui", ["error-rate", "latency"])
# advance_flag_stage("release-profile-ui", "active", test_stage_id)
# advance_flag_stage("release-profile-ui", "completed", test_stage_id)
# advance_flag_stage("release-profile-ui", "active", guard_stage_id)
# advance_flag_stage("release-profile-ui", "completed", guard_stage_id)

####
## For:
## - release-api-rate-limit
## - release-currency-exchange
##
## bump from testing to Release
####

# attach_metric_to_flag("release-api-rate-limit", ["latency"])
# advance_flag_stage("release-api-rate-limit", "active", test_stage_id)
# advance_flag_stage("release-api-rate-limit", "completed", test_stage_id)
# advance_flag_stage("release-api-rate-limit", "active", guard_stage_id)
# advance_flag_stage("release-api-rate-limit", "completed", guard_stage_id)
# advance_flag_stage("release-api-rate-limit", "active", ga_stage_id)
# advance_flag_stage("release-api-rate-limit", "completed", ga_stage_id)

# attach_metric_to_flag("release-currency-exchange", ["error-rate"])
# advance_flag_stage("release-currency-exchange", "active", test_stage_id)
# advance_flag_stage("release-currency-exchange", "completed", test_stage_id)
# advance_flag_stage("release-currency-exchange", "active", guard_stage_id)
# advance_flag_stage("release-currency-exchange", "completed", guard_stage_id)
# advance_flag_stage("release-currency-exchange", "active", ga_stage_id)
# advance_flag_stage("release-currency-exchange", "completed", ga_stage_id)
