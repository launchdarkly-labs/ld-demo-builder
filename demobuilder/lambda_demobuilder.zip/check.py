import os
import sys
import json
import requests

project_key = "cxld-pink-canoe"
api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"

# payload = {
#     "name": "AI Flags",
#     "key": "ai-flags",
#     "icon": "bolt",
#     "type": "flags",
#     "context": {
#         "projectKey": project_key,
#         "environmentKeys": ["production", "test"],
#         "selectedEnvironmentKey": "production",
#     },
#     "filters": {"filter": {"tags": ["AI"]}},
#     "visibility": "me",
# }
url = (
    "https://app.launchdarkly.com/api/v2/projects/"
    + project_key
    + "/flags/config-ai-foundation-model/measured-rollout-configuration"
)

headers = {
    "Content-Type": "application/json",
    "Authorization": api_key,
    "LD-API-Version": "beta",
}

payload = {"metricKeys": ["error-rate", "latency"]}

response = requests.put(url, json=payload, headers=headers)
print(response.text)
