import os
import sys
import json
import urllib3
import randomname


body = {
    "action": "build",
}

print(body["action"])
