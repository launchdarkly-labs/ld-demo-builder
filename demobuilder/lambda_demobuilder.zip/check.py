import os
import sys
import json
import requests

project_key = "cxld-quiet-tropics"
api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"
env_key = "production"
pipeline_key = "default-releases"

# payload = {
#     "name": "AI Flags",
#     "key": "ai-flags",
#     "icon": "bolt",
#     "type": "flags",
#     "context": {
#         "projectKey": project_key,
#         "environmentKeys": ["production", "test"],
#         "selectedEnvironmentKey": "production",
#     },
#     "filters": {"filter": {"tags": ["AI"]}},
#     "visibility": "me",
# }

url = (
    "https://app.launchdarkly.com/api/v2/projects/"
    + project_key
    + "/release-pipelines/"
    + pipeline_key
)

headers = {
    "Content-Type": "application/json",
    "Authorization": api_key,
    "LD-API-Version": "beta",
}


response = requests.get(url, headers=headers)
print(response.text)
# data = json.loads(response.text)
# for member in data["items"]:
#     print(member["firstName"] + " " + member["lastName"])
#     if member["email"] == "kcochran@launchdarkly.com":
#         print(member["_id"] + ": " + member["firstName"] + " " + member["lastName"])
#         break

# print(data["variations"][0]["_id"])

# export LD_API_KEY_USER=api-451cd896-2388-4aaa-a713-11807acdf8c6
