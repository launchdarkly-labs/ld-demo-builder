import os
import sys
import json
import requests

project_key = "cxld-massive-mortar"
api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"
env_key = "production"
pipeline_key = "default-releases"

# payload = {
#     "name": "AI Flags",
#     "key": "ai-flags",
#     "icon": "bolt",
#     "type": "flags",
#     "context": {
#         "projectKey": project_key,
#         "environmentKeys": ["production", "test"],
#         "selectedEnvironmentKey": "production",
#     },
#     "filters": {"filter": {"tags": ["AI"]}},
#     "visibility": "me",
# }

url = "https://app.launchdarkly.com/api/v2/flags/cxld-electric-tangerine/show-ai-model"
headers = {
    "Authorization": api_key,
    "Content-Type": "application/json",
}
payload = [
    {
        "op": "replace",
        "path": "/maintainerId",
        "value": "569f183514f4432160000007",
    }
]

response = requests.patch(url, headers=headers, json=payload)
# data = json.loads(response.text)

print(response.text)


# rg_data = data["environments"]["production"]["fallthrough"]
# if "rollout" in rg_data:
#     print(rg_data["rollout"]["experimentAllocation"]["type"])
# print(rg_data["experimentAllocation"])

#### for getting memberId
# data = json.loads(response.text)
# for member in data["items"]:
#     print(member["firstName"] + " " + member["lastName"])
#     if member["email"] == "kcochran@launchdarkly.com":
#         print(member["_id"] + ": " + member["firstName"] + " " + member["lastName"])
#         break

# print(data["variations"][0]["_id"])

# export LD_API_KEY_USER=api-451cd896-2388-4aaa-a713-11807acdf8c6


# curl -s -X PUT \
#     -H "Content-Type: application/json" \
#     -H "Authorization: "$LD_API_KEY"" \
#     -H "LD-API-Version: beta" \
#     -d '{ "name": "Audience", "key": "audience", "description": "", "hideInTargeting": false }' \
#     "https://app.launchdarkly.com/api/v2/projects/cxld-massive-mortar/context-kinds/audience"

# curl -s -X PATCH \
#     -H "Content-Type: application/json" \
#     -H "Authorization: "$LD_API_KEY"" \
#     -H "LD-API-Version: beta" \
#     -d '[{"op": "replace", "path": "/requireComments", "value": false},{"op": "replace", "path": "/confirmChanges", "value": false}]' \
#     "https://app.launchdarkly.com/api/v2/projects/cxld-massive-mortar/environments/production"

# curl -s -X GET \
#     -H "Content-Type: application/json" \
#     -H "Authorization: "$LD_API_KEY"" \
#     "https://app.launchdarkly.com/api/v2/members?filter=email:kcochran@launchdarkly.com"

# curl -s -X GET \
#     -H "Content-Type: application/json" \
#     -H "Authorization: "$LD_API_KEY"" \
#     "https://app.launchdarkly.com/api/v2/segments/cxld-massive-mortar/test/developers"


# curl -s -X POST \
#   https://app.launchdarkly.com/api/v2/tokens \
#   -H 'Authorization: '$LD_API_KEY'' \
#   -H 'Content-Type: application/json' \
#   -d '{
#     "role": "admin"
#   }'
