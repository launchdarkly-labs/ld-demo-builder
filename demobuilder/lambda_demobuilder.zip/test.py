import requests
import json
import os
import boto3


# project_key = "rustoleum-xyz"
# api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"

# ddb = boto3.resource("dynamodb", region_name="us-east-2")
# table = ddb.Table("coastdemo-demo-tracker")

# response = table.scan()
# data = response["Items"]
# while "LastEvaluatedKey" in response:
#     response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
#     data.extend(response["Items"])

# for item in data:
#     headers = {
#         "Authorization": api_key,
#         "Content-Type": "application/json",
#     }

#     res = requests.get(
#         "https://app.launchdarkly.com/api/v2/projects/" + item["ProjectKey"],
#         headers=headers,
#     )

#     proj = json.loads(res.text)
#     if "message" in proj:
#         print(item["ProjectKey"] + " does not exist (" + item["UserId"] + ")")


project_key = "cxld-connected-fort"
flag_key = "release-fire-overlay"
api_key = "api-451cd896-2388-4aaa-a713-11807acdf8c6"

url = (
    "https://app.launchdarkly.com/api/v2/flags/"
    + project_key
    + "/"
    + flag_key
    + "?ignoreConflicts=true"
)
headers = {
    "Authorization": api_key,
    "Content-Type": "application/json; domain-model=launchdarkly.semanticpatch",
    "LD-API-Version": "beta",
}
payload = {
    "comment": "",
    "environmentKey": "production",
    "instructions": [
        {
            "kind": "updateFallthroughWithMeasuredRollout",
            "testVariationId": "7c98bada-b17d-4dc8-8d58-4e832445208a",
            "controlVariationId": "b113d923-9f45-4e12-baa8-f0e3c1489605",
            "randomizationUnit": "user",
            "onRegression": {"notify": True, "rollback": True},
            "onProgression": {"notify": True, "rollForward": True},
            "monitoringWindowMilliseconds": 604800000,
            "rolloutWeight": 50000,
        }
    ],
}

res = requests.patch(url, headers=headers, json=payload)
print(res.status_code)
print(res.headers)
print(res.text)


# curl 'https://app.launchdarkly.com/api/v2/flags/cxld-connected-fort/release-fire-overlay?ignoreConflicts=true' \
#   -X 'PATCH' \
#   -H 'Authorization: api-451cd896-2388-4aaa-a713-11807acdf8c6' \
#   -H 'Content-Type: application/json; domain-model=launchdarkly.semanticpatch' \
#   -H 'LD-API-Version: beta' \
#   -d '{"comment":"","environmentKey":"production","instructions":[{"kind":"updateFallthroughWithMeasuredRollout","testVariationId":"7c98bada-b17d-4dc8-8d58-4e832445208a","controlVariationId":"b113d923-9f45-4e12-baa8-f0e3c1489605","randomizationUnit":"user","onRegression":{"notify":true,"rollback":true},"onProgression":{"notify":true,"rollForward":true},"monitoringWindowMilliseconds":3600000,"rolloutWeight":50000}]}'
