# import requests
import json
import os

api_key = os.environ["LD_API_KEY"]
project_key = "cxld-raw-zoning"

exp_key = "ai-analysis-to-advisor"
exp_name = "AI Analysis to Advisor"
hypothesis = "We believe that by using more up to date AI models, we will increase customer conversions to contact their advisor."
primary_funnel_key = "ai-to-advisor-conversion"
flag_key = "config-ai-model"
attributes = ["plan", "beta", "metro", "net_worth"]


# payload = {
#     "name": exp_name,
#     "key": exp_key,
#     "maintainerId": "5f9b3b7b7f7b7d001f7b7f7b",
#     "iteration": {
#         "hypothesis": hypothesis,
#         "canReshuffleTraffic": True,
#         "metrics": self.get_exp_metrics(),
#         "primaryFunnelKey": primary_funnel_key,
#         "treatments": self.get_treatments(flag_key),
#         "flags": {
#             flag_key: {
#                 "ruleId": "fallthrough",
#                 "flagConfigVersion": 1,
#             },
#         },
#         "randomizationUnit": "user",
#         "attributes": attributes,
#     },
# }

headers = {
    "Authorization": api_key,
    "Content-Type": "application/json",
    "LD-API-Version": "beta",
}

# res = requests.post(
#     "https://app.launchdarkly.com/api/v2/projects/"
#     + project_key
#     + "/environments/production/experiments",
#     json=payload,
#     headers=headers,
# )

# print(res.text)

# obj = json.loads(res.text)
# if "message" in obj:
#     print("Does not exist")
# else:
#     print("Exists!")


# curl -s -X GET \
#   'https://app.launchdarkly.com/api/v2/projects/platform-demo/release-pipelines/default-releases/releases' \
#   -H 'Authorization: api-451cd896-2388-4aaa-a713-11807acdf8c6' \
#   -H 'LD-API-Version: beta'

# curl -i -X GET \
#   'https://app.launchdarkly.com/api/v2/projects/platform-demo/release-pipelines' \
#   -H 'Authorization: api-451cd896-2388-4aaa-a713-11807acdf8c6' \
#   -H 'LD-API-Version: beta'

# curl -s -X GET \
#   'https://app.launchdarkly.com/api/v2/flags/cxld-raw-zoning/config-ai-model' \
#   -H 'Authorization: api-451cd896-2388-4aaa-a713-11807acdf8c6'


# curl -s -X PATCH \
#   'https://app.launchdarkly.com/api/v2/flags/cxld-bitter-element/config-ai-model' \
#   -H 'Authorization: api-451cd896-2388-4aaa-a713-11807acdf8c6' \
#   -H 'Content-Type: application/json; domain-model=launchdarkly.semanticpatch' \
#   -d '{
#   "comment": "Turn flag on for experiment",
#   "environmentKey": "production",
#   "instructions": [ { "kind": "turnFlagOn" } ]
# }'

# {
#   "comment": "Turn flag on for experiment",
#   "environmentKey": "production",
#   "instructions": [ { "kind": "turnFlagOff" } ]
# }

# {
#     "instructions": [
#         {
#             "kind": "startIteration",
#             "changeJustification": "Time to start the experiment!",
#         }
#     ]
# }


# curl -i -X POST \
#   'https://app.launchdarkly.com/api/v2/flags/rustoleum' \
#   -H 'Authorization: api-451cd896-2388-4aaa-a713-11807acdf8c6' \
#   -H 'Content-Type: application/json' \
#   -d '{
#     "clientSideAvailability": {
#       "usingEnvironmentId": true,
#       "usingMobileKey": true
#     },
#     "key": "flag-key-123abc",
#     "name": "My Flag"
#   }'
